#ifndef ADDPAGE_H
#define ADDPAGE_H

class addpage
{
public:
    addpage();
};

#endif // ADDPAGE_H
