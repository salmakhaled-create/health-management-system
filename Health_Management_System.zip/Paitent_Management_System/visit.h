#ifndef VISIT_H
#define VISIT_H

#include <QString>

struct Visit {
    QString patientId;
    QString patientName;
    QString doctorName;
    QString doctorSpecialization;
    QString diagnosis;
    QString medication;
    QString dateTime;
};

#endif