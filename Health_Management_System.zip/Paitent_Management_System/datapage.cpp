#include "datapage.h"
#include "datastore.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>

DataPage::DataPage(QWidget* parent) : QWidget(parent) {
    searchEdit = new QLineEdit(this);
    searchEdit->setPlaceholderText("Search by Patient ID...");
    searchBtn  = new QPushButton("Search", this);
    clearBtn   = new QPushButton("Show All", this);
    QHBoxLayout* searchLayout = new QHBoxLayout;
    searchLayout->addWidget(searchEdit);
    searchLayout->addWidget(searchBtn);
    searchLayout->addWidget(clearBtn);

    table = new QTableWidget(this);
    table->setColumnCount(7);
    table->setHorizontalHeaderLabels({
        "Name", "ID", "Doctor", "Specialization",
        "Diagnosis", "Medication / Notes", "Status"
    });
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setAlternatingRowColors(true);
    table->verticalHeader()->setVisible(false);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(20, 20, 20, 20);
    layout->setSpacing(12);
    QLabel* title = new QLabel("Patient Records", this);
    title->setStyleSheet("font-size: 20px; font-weight: bold; color: #2c3e50;");
    layout->addWidget(title);
    layout->addLayout(searchLayout);
    layout->addWidget(table);
    connect(searchBtn, &QPushButton::clicked, this, &DataPage::searchById);
    connect(clearBtn,  &QPushButton::clicked, this, &DataPage::clearSearch);
    connect(searchEdit, &QLineEdit::returnPressed, this, &DataPage::searchById);
    populateTable();
}

void DataPage::refreshTable() {
    populateTable(searchEdit->text().trimmed());
}

void DataPage::searchById() {
    populateTable(searchEdit->text().trimmed());
}

void DataPage::clearSearch() {
    searchEdit->clear();
    populateTable();
}

void DataPage::populateTable(const QString& filterById) {
    const QList<Patient>& patients = DataStore::instance().allPatients();
    table->setRowCount(0); // clear
    for (const Patient& p : patients) {
        if (!filterById.isEmpty() && p.id != filterById)
            continue;
        int row = table->rowCount();
        table->insertRow(row);
        table->setItem(row, 0, new QTableWidgetItem(p.name));
        table->setItem(row, 1, new QTableWidgetItem(p.id));
        table->setItem(row, 2, new QTableWidgetItem(p.doctorName));
        table->setItem(row, 3, new QTableWidgetItem(p.doctorSpecialization));
        table->setItem(row, 4, new QTableWidgetItem(p.diagnosis.isEmpty()  ? "-" : p.diagnosis));
        table->setItem(row, 5, new QTableWidgetItem(p.medication.isEmpty() ? "-" : p.medication));
        QString status = p.checkedOut ? "Checked Out" : "Checked In";
        QTableWidgetItem* statusItem = new QTableWidgetItem(status);
        statusItem->setForeground(p.checkedOut
                                      ? QColor("#e74c3c")
                                      : QColor("#27ae60"));
        statusItem->setFont(QFont("", -1, QFont::Bold));
        table->setItem(row, 6, statusItem);
    }
}
