#include "paitent.h"

paitent::paitent() {}
