#include "loginpage.h"
#include <QVBoxLayout>
#include <QFormLayout>

LoginPage::LoginPage(LoginRole role, QWidget* parent)
    : QWidget(parent), role(role)
{
    QString title = (role == LoginRole::Hospital) ? "Hospital Login" : "Pharmacy Login";
    QString hint = (role == LoginRole::Hospital) ? "admin1" : "admin2";

    QLabel* titleLabel = new QLabel(title, this);
    titleLabel->setStyleSheet("font-size: 22px; font-weight: bold; color: #2c3e50;");
    titleLabel->setAlignment(Qt::AlignCenter);
    QLabel* subtitleLabel = new QLabel(
        (role == LoginRole::Hospital)
            ? "Hospital staff access only"
            : "Pharmacy staff access only", this);
    subtitleLabel->setAlignment(Qt::AlignCenter);
    subtitleLabel->setStyleSheet("color: #7f8c8d; font-size: 13px;");

    usernameEdit = new QLineEdit(this);
    usernameEdit->setPlaceholderText("Username");

    passwordEdit = new QLineEdit(this);
    passwordEdit->setPlaceholderText("Password");
    passwordEdit->setEchoMode(QLineEdit::Password);

    errorLabel = new QLabel(this);
    errorLabel->setStyleSheet("color: #e74c3c; font-weight: bold;");
    errorLabel->setAlignment(Qt::AlignCenter);
    errorLabel->hide();

    loginBtn = new QPushButton("Login", this);
    backBtn = new QPushButton("← Back", this);
    backBtn->setStyleSheet("background: #95a5a6;");

    QFormLayout* form = new QFormLayout;
    form->setSpacing(12);
    form->addRow("Username:", usernameEdit);
    form->addRow("Password:", passwordEdit);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(120, 60, 120, 60);
    layout->setSpacing(16);
    layout->addWidget(titleLabel);
    layout->addWidget(subtitleLabel);
    layout->addSpacing(20);
    layout->addLayout(form);
    layout->addWidget(errorLabel);
    layout->addWidget(loginBtn);
    layout->addWidget(backBtn);
    layout->addStretch();

    connect(loginBtn, &QPushButton::clicked, this, &LoginPage::attemptLogin);
    connect(backBtn, &QPushButton::clicked, this, &LoginPage::backRequested);
    connect(passwordEdit, &QLineEdit::returnPressed, this, &LoginPage::attemptLogin);
}

void LoginPage::attemptLogin() {
    QString user = usernameEdit->text().trimmed();
    QString pass = passwordEdit->text();

    bool ok = false;
    if (role == LoginRole::Hospital)
        ok = (user == "admin1" && pass == "1234");
    else
        ok = (user == "admin2" && pass == "5678");

    if (ok) {
        errorLabel->hide();
        usernameEdit->clear();
        passwordEdit->clear();
        emit loginSuccess();
    } else {
        errorLabel->setText("Incorrect username or password.");
        errorLabel->show();
        passwordEdit->clear();
    }
}