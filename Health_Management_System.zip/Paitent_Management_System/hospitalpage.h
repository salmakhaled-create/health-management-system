#ifndef HOSPITALPAGE_H
#define HOSPITALPAGE_H

#include <QWidget>
#include <QTabWidget>
#include "checkinpage.h"
#include "checkoutpage.h"
#include "datapage.h"
class HospitalPage : public QWidget {
    Q_OBJECT

public:
    explicit HospitalPage(QWidget* parent = nullptr);

private:
    QTabWidget* tabs;
    CheckInPage* checkInPage;
    CheckOutPage* checkOutPage;
    DataPage* dataPage;
};

#endif
