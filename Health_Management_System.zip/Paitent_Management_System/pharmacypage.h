#ifndef PHARMACYPAGE_H
#define PHARMACYPAGE_H
#include <QWidget>
#include <QTabWidget>
#include "addprescriptionpage.h"
#include "pickupprescriptionpage.h"

class PharmacyPage : public QWidget {
Q_OBJECT

public:
    explicit PharmacyPage(QWidget* parent = nullptr);

private:
    QTabWidget* tabs;
    AddPrescriptionPage* addPage;
    PickupPrescriptionPage* pickupPage;
};

#endif