#ifndef PATIENTPORTAL_H
#define PATIENTPORTAL_H
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QTableWidget>
#include <QStackedWidget>

class PatientPortal : public QWidget {
    Q_OBJECT
public:
    explicit PatientPortal(QWidget* parent = nullptr);
private slots:
    void handleLogin();
    void handleLogout();
private:
    QStackedWidget* stack;
    QWidget* loginScreen;
    QLineEdit* nameEdit;
    QLineEdit* idEdit;
    QPushButton* loginBtn;
    QLabel* errorLabel;
    QWidget* recordsScreen;
    QLabel* welcomeLabel;
    QTableWidget* rxTable;
    QTableWidget* hospitalTable;
    QPushButton* logoutBtn;
    void buildLoginScreen();
    void buildRecordsScreen();
    void populateRecords(const QString& name, const QString& id);
};

#endif
