#ifndef ADDPRESCRIPTIONPAGE_H
#define ADDPRESCRIPTIONPAGE_H
#include <QWidget>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>

class AddPrescriptionPage : public QWidget {
    Q_OBJECT

public:
    explicit AddPrescriptionPage(QWidget* parent = nullptr);

signals:
    void prescriptionAdded();

private slots:
    void handleSubmit();

private:
    QLineEdit* patientNameEdit;
    QLineEdit* patientIdEdit;
    QLineEdit* pharmacistNameEdit;
    QLineEdit* diagnosisEdit;
    QTextEdit* medicationEdit;
    QPushButton* submitBtn;
    QLabel* statusLabel;
};

#endif