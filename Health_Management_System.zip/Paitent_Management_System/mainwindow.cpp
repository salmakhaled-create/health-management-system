#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLabel>

MainWindow::MainWindow(QWidget * parent) : QMainWindow(parent) {
    setWindowTitle("Health Management System");
    resize(960, 660);

    stack = new QStackedWidget(this);
    setCentralWidget(stack);

    // Build all pages
    buildLandingPage();
    hospitalLogin = new LoginPage(LoginRole::Hospital, this);
    pharmacyLogin = new LoginPage(LoginRole::Pharmacy, this);
    hospitalPage = new HospitalPage(this);
    pharmacyPage = new PharmacyPage(this);
    patientPortal = new PatientPortal(this);

    // Add to stack (order matters — we switch by pointer, not index)
    stack->addWidget(landingPage);
    stack->addWidget(hospitalLogin);
    stack->addWidget(pharmacyLogin);
    stack->addWidget(hospitalPage);
    stack->addWidget(pharmacyPage);
    stack->addWidget(patientPortal);

    // --- Connections ---
    connect(hospitalLogin, &LoginPage::loginSuccess, this, &MainWindow::showHospitalModule);
    connect(hospitalLogin, &LoginPage::backRequested, this, &MainWindow::showLanding);

    connect(pharmacyLogin, &LoginPage::loginSuccess, this, &MainWindow::showPharmacyModule);
    connect(pharmacyLogin, &LoginPage::backRequested, this, &MainWindow::showLanding);

    // Global stylesheet
    setStyleSheet(R"(
        QTabWidget::pane { border: 1px solid #dce1e7; border-radius: 4px; }
        QTabBar::tab { padding: 8px 20px; font-size: 13px; font-weight: 500; }
        QTabBar::tab:selected { background: #2980b9; color: white; border-radius: 4px 4px 0 0; }
        QLineEdit, QTextEdit {
            border: 1px solid #bdc3c7; border-radius: 4px;
            padding: 5px 8px; font-size: 13px;
        }
        QLineEdit:focus, QTextEdit:focus { border-color: #2980b9; }
        QPushButton {
            background: #2980b9; color: white; border: none;
            padding: 7px 18px; border-radius: 4px;
            font-size: 13px; font-weight: 500;
        }
        QPushButton:hover  { background: #3498db; }
        QPushButton:pressed{ background: #1a6fa3; }
        QTableWidget { font-size: 12px; gridline-color: #ecf0f1; }
        QHeaderView::section {
            background: #34495e; color: white;
            padding: 6px; font-weight: bold; border: none;
        }
    )");
}

void MainWindow::buildLandingPage() {
    landingPage = new QWidget(this);

    QLabel* title = new QLabel("Health Management System", landingPage);
    title->setStyleSheet("font-size: 28px; font-weight: bold; color: #2c3e50;");
    title->setAlignment(Qt::AlignCenter);

    QLabel* subtitle = new QLabel("Select your section to continue", landingPage);
    subtitle->setStyleSheet("font-size: 14px; color: #7f8c8d;");
    subtitle->setAlignment(Qt::AlignCenter);

    // Three big buttons
    QPushButton* hospitalBtn = new QPushButton("🏥  Hospital System", landingPage);
    QPushButton* pharmacyBtn = new QPushButton("💊  Pharmacy System", landingPage);
    QPushButton* portalBtn = new QPushButton("👤  Patient Portal", landingPage);

    QString bigBtn = "font-size: 15px; padding: 18px 30px; border-radius: 8px;";
    hospitalBtn->setStyleSheet(bigBtn + "background: #2980b9;");
    pharmacyBtn->setStyleSheet(bigBtn + "background: #27ae60;");
    portalBtn->setStyleSheet(bigBtn + "background: #8e44ad;");

    QVBoxLayout* btnLayout = new QVBoxLayout;
    btnLayout->setSpacing(16);
    btnLayout->addWidget(hospitalBtn);
    btnLayout->addWidget(pharmacyBtn);
    btnLayout->addWidget(portalBtn);

    QVBoxLayout* layout = new QVBoxLayout(landingPage);
    layout->setContentsMargins(200, 80, 200, 80);
    layout->setSpacing(12);
    layout->addStretch();
    layout->addWidget(title);
    layout->addWidget(subtitle);
    layout->addSpacing(40);
    layout->addLayout(btnLayout);
    layout->addStretch();

    connect(hospitalBtn, &QPushButton::clicked, this, &MainWindow::showHospitalLogin);
    connect(pharmacyBtn, &QPushButton::clicked, this, &MainWindow::showPharmacyLogin);
    connect(portalBtn, &QPushButton::clicked, this, &MainWindow::showPatientPortal);
}
void MainWindow::showLanding() { stack->setCurrentWidget(landingPage); }
void MainWindow::showHospitalLogin() { stack->setCurrentWidget(hospitalLogin); }
void MainWindow::showPharmacyLogin() { stack->setCurrentWidget(pharmacyLogin); }
void MainWindow::showHospitalModule() { stack->setCurrentWidget(hospitalPage); }
void MainWindow::showPharmacyModule() { stack->setCurrentWidget(pharmacyPage); }
void MainWindow::showPatientPortal() { stack->setCurrentWidget(patientPortal); }