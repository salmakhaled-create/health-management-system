#ifndef PICKUPPRESCRIPTIONPAGE_H
#define PICKUPPRESCRIPTIONPAGE_H

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QTableWidget>

class PickupPrescriptionPage : public QWidget {
    Q_OBJECT

public:
    explicit PickupPrescriptionPage(QWidget* parent = nullptr);

private slots:
    void handleSearch();
    void handleMarkTaken();

private:
    QLineEdit* nameEdit;
    QLineEdit* idEdit;
    QPushButton* searchBtn;
    QTableWidget* resultsTable;
    QPushButton* markTakenBtn;
    QLabel* statusLabel;
};

#endif
