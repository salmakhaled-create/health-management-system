#include "checkinpage.h"
#include "datastore.h"
#include "patient.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QMessageBox>

CheckInPage::CheckInPage(QWidget* parent) : QWidget(parent) {

    nameEdit = new QLineEdit(this);
    idEdit = new QLineEdit(this);
    doctorNameEdit = new QLineEdit(this);
    doctorSpecEdit = new QLineEdit(this);
    submitBtn = new QPushButton("Check In Patient", this);
    statusLabel = new QLabel(this);
    nameEdit->setPlaceholderText("e.g. Sarah Ahmed");
    idEdit->setPlaceholderText("e.g. 10234");
    doctorNameEdit->setPlaceholderText("e.g. Dr. Khaled Omar");
    doctorSpecEdit->setPlaceholderText("e.g. Cardiology");
    statusLabel->setStyleSheet("color: green; font-weight: bold;");

    QFormLayout* form = new QFormLayout;
    form->setSpacing(12);
    form->addRow("Patient Name:", nameEdit);
    form->addRow("Patient ID:", idEdit);
    form->addRow("Assigned Doctor:", doctorNameEdit);
    form->addRow("Doctor Specialization:", doctorSpecEdit);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(40, 30, 40, 30);
    layout->setSpacing(16);
    QLabel* title = new QLabel("Patient Check-In", this);
    title->setStyleSheet("font-size: 20px; font-weight: bold; color: #2c3e50;");
    layout->addWidget(title);
    layout->addSpacing(8);
    layout->addLayout(form);
    layout->addWidget(submitBtn);
    layout->addWidget(statusLabel);
    layout->addStretch();
    connect(submitBtn, &QPushButton::clicked, this, &CheckInPage::handleCheckIn);
}

void CheckInPage::handleCheckIn() {
    QString name = nameEdit->text().trimmed();
    QString id = idEdit->text().trimmed();
    QString docName = doctorNameEdit->text().trimmed();
    QString docSpec = doctorSpecEdit->text().trimmed();

    if (name.isEmpty() || id.isEmpty() || docName.isEmpty() || docSpec.isEmpty()) {
        QMessageBox::warning(this, "Incomplete Form", "Please fill in all fields before submitting.");
        return;
    }
    if (DataStore::instance().findById(id) != nullptr) {
        QMessageBox::warning(this, "Duplicate ID", "A patient with this ID is already checked in.");
        return;
    }
    Patient p;
    p.name = name;
    p.id = id;
    p.doctorName = docName;
    p.doctorSpecialization = docSpec;
    DataStore::instance().addPatient(p);
    statusLabel->setText("✔ Patient \"" + name + "\" checked in successfully.");

    nameEdit->clear();
    idEdit->clear();
    doctorNameEdit->clear();
    doctorSpecEdit->clear();
    emit patientCheckedIn();
}