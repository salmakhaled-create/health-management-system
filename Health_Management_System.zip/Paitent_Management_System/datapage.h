#ifndef DATAPAGE_H
#define DATAPAGE_H

#include <QWidget>
#include <QTableWidget>
#include <QLineEdit>
#include <QPushButton>
class DataPage : public QWidget {
    Q_OBJECT
public:
    explicit DataPage(QWidget* parent = nullptr);
public slots:
    void refreshTable();
private slots:
    void searchById();
    void clearSearch();
private:
    QTableWidget* table;
    QLineEdit* searchEdit;
    QPushButton* searchBtn;
    QPushButton* clearBtn;
    void populateTable(const QString& filterById = QString());
};

#endif
