#include <QApplication>
#include "mainwindow.h"
#include "datastore.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    app.setApplicationName("PaitentManagementSystem");

    DataStore::instance().load();

    MainWindow w;
    w.show();

    return app.exec();
}