#include "patientportal.h"
#include "datastore.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QHeaderView>
#include <QScrollArea>

PatientPortal::PatientPortal(QWidget* parent) : QWidget(parent) {

    stack = new QStackedWidget(this);

    buildLoginScreen();
    buildRecordsScreen();

    stack->addWidget(loginScreen);
    stack->addWidget(recordsScreen);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->addWidget(stack);
}

void PatientPortal::buildLoginScreen() {
    loginScreen = new QWidget(this);

    QLabel* title = new QLabel("Patient Portal", loginScreen);
    title->setStyleSheet("font-size: 24px; font-weight: bold; color: #2c3e50;");
    title->setAlignment(Qt::AlignCenter);

    QLabel* subtitle = new QLabel(
        "View your full medical history, past visits and all prescriptions", loginScreen);
    subtitle->setStyleSheet("color: #7f8c8d; font-size: 13px;");
    subtitle->setAlignment(Qt::AlignCenter);
    subtitle->setWordWrap(true);

    nameEdit = new QLineEdit(loginScreen);
    nameEdit->setPlaceholderText("Your full name");

    idEdit = new QLineEdit(loginScreen);
    idEdit->setPlaceholderText("Your patient ID");

    errorLabel = new QLabel(loginScreen);
    errorLabel->setStyleSheet("color: #e74c3c; font-weight: bold;");
    errorLabel->setAlignment(Qt::AlignCenter);
    errorLabel->hide();

    loginBtn = new QPushButton("View My Records", loginScreen);

    QFormLayout* form = new QFormLayout;
    form->setSpacing(12);
    form->addRow("Name:", nameEdit);
    form->addRow("ID:",   idEdit);

    QVBoxLayout* layout = new QVBoxLayout(loginScreen);
    layout->setContentsMargins(120, 60, 120, 60);
    layout->setSpacing(16);
    layout->addWidget(title);
    layout->addWidget(subtitle);
    layout->addSpacing(20);
    layout->addLayout(form);
    layout->addWidget(errorLabel);
    layout->addWidget(loginBtn);
    layout->addStretch();

    connect(loginBtn, &QPushButton::clicked, this, &PatientPortal::handleLogin);
    connect(idEdit, &QLineEdit::returnPressed, this, &PatientPortal::handleLogin);
}

void PatientPortal::buildRecordsScreen() {
    recordsScreen = new QWidget(this);

    welcomeLabel = new QLabel(recordsScreen);
    welcomeLabel->setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;");

    // ── Hospital visit history table ──
    QLabel* hospitalTitle = new QLabel("🏥  Hospital Visit History", recordsScreen);
    hospitalTitle->setStyleSheet("font-size: 14px; font-weight: bold; color: #34495e;");

    QLabel* hospitalNote = new QLabel(
        "All past visits are kept here permanently, even after checkout.", recordsScreen);
    hospitalNote->setStyleSheet("color: #7f8c8d; font-size: 11px;");

    hospitalTable = new QTableWidget(recordsScreen);
    hospitalTable->setColumnCount(5);
    hospitalTable->setHorizontalHeaderLabels(
        {"Date", "Doctor", "Specialization", "Diagnosis", "Medication"});
    hospitalTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    hospitalTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    hospitalTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    hospitalTable->verticalHeader()->setVisible(false);
    hospitalTable->setAlternatingRowColors(true);
    hospitalTable->setMinimumHeight(160);

    // ── Prescriptions table ──
    QLabel* rxTitle = new QLabel("💊  Prescription History", recordsScreen);
    rxTitle->setStyleSheet("font-size: 14px; font-weight: bold; color: #34495e;");

    QLabel* rxNote = new QLabel(
        "All prescriptions — pending and already dispensed — appear here.", recordsScreen);
    rxNote->setStyleSheet("color: #7f8c8d; font-size: 11px;");

    rxTable = new QTableWidget(recordsScreen);
    rxTable->setColumnCount(3);
    rxTable->setHorizontalHeaderLabels({"Diagnosis", "Medication", "Status"});
    rxTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    rxTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    rxTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    rxTable->verticalHeader()->setVisible(false);
    rxTable->setAlternatingRowColors(true);
    rxTable->setMinimumHeight(140);

    logoutBtn = new QPushButton("← Log Out", recordsScreen);
    logoutBtn->setStyleSheet("background: #95a5a6;");

    QVBoxLayout* layout = new QVBoxLayout(recordsScreen);
    layout->setContentsMargins(30, 25, 30, 25);
    layout->setSpacing(8);
    layout->addWidget(welcomeLabel);
    layout->addSpacing(8);
    layout->addWidget(hospitalTitle);
    layout->addWidget(hospitalNote);
    layout->addWidget(hospitalTable);
    layout->addSpacing(12);
    layout->addWidget(rxTitle);
    layout->addWidget(rxNote);
    layout->addWidget(rxTable);
    layout->addSpacing(12);
    layout->addWidget(logoutBtn);
    layout->addStretch();

    connect(logoutBtn, &QPushButton::clicked, this, &PatientPortal::handleLogout);
}

void PatientPortal::handleLogin() {
    QString name = nameEdit->text().trimmed();
    QString id   = idEdit->text().trimmed();

    if (name.isEmpty() || id.isEmpty()) {
        errorLabel->setText("Please enter both your name and ID.");
        errorLabel->show();
        return;
    }

    // Accept if patient exists in hospital records (even just checked in, no visit yet)
    // OR has prescription history
    Patient* p = DataStore::instance().findById(id);
    QList<Visit> visitList = DataStore::instance().allVisitsFor(id);
    QList<Prescription> rxList = DataStore::instance().allPrescriptionsFor(id);

    bool foundInHospital = (p != nullptr && p->name.toLower() == name.toLower());
    bool foundInVisits   = (!visitList.isEmpty() &&
                          visitList.first().patientName.toLower() == name.toLower());
    bool foundInPharmacy = (!rxList.isEmpty() &&
                            rxList.first().patientName.toLower() == name.toLower());

    if (!foundInHospital && !foundInVisits && !foundInPharmacy) {
        errorLabel->setText("No records found for this name and ID combination.");
        errorLabel->show();
        return;
    }

    errorLabel->hide();
    populateRecords(name, id);
    welcomeLabel->setText("Welcome, " + name + "  (ID: " + id + ")");
    stack->setCurrentIndex(1);
}

void PatientPortal::handleLogout() {
    nameEdit->clear();
    idEdit->clear();
    hospitalTable->setRowCount(0);
    rxTable->setRowCount(0);
    stack->setCurrentIndex(0);
}

void PatientPortal::populateRecords(const QString& /*name*/, const QString& id) {
    // ── Hospital Visit History (from Visit table — complete history) ──
    hospitalTable->setRowCount(0);
    QList<Visit> visitList = DataStore::instance().allVisitsFor(id);
    for (const Visit& v : visitList) {
        int row = hospitalTable->rowCount();
        hospitalTable->insertRow(row);

        // Format the date nicely if possible
        QString displayDate = v.dateTime;
        QDateTime dt = QDateTime::fromString(v.dateTime, Qt::ISODate);
        if (dt.isValid())
            displayDate = dt.toString("dd MMM yyyy  hh:mm");

        hospitalTable->setItem(row, 0, new QTableWidgetItem(displayDate));
        hospitalTable->setItem(row, 1, new QTableWidgetItem(v.doctorName));
        hospitalTable->setItem(row, 2, new QTableWidgetItem(v.doctorSpecialization));
        hospitalTable->setItem(row, 3, new QTableWidgetItem(v.diagnosis));
        hospitalTable->setItem(row, 4, new QTableWidgetItem(v.medication));
    }

    if (visitList.isEmpty()) {
        hospitalTable->insertRow(0);
        QTableWidgetItem* noVisit = new QTableWidgetItem("No completed visits on record yet.");
        noVisit->setForeground(QColor("#95a5a6"));
        hospitalTable->setItem(0, 0, noVisit);
        hospitalTable->setSpan(0, 0, 1, 5);
    }

    // ── Prescription History (ALL — pending and dispensed) ──
    rxTable->setRowCount(0);
    QList<Prescription> rxList = DataStore::instance().allPrescriptionsFor(id);
    for (const Prescription& rx : rxList) {
        int row = rxTable->rowCount();
        rxTable->insertRow(row);
        rxTable->setItem(row, 0, new QTableWidgetItem(rx.diagnosis));
        rxTable->setItem(row, 1, new QTableWidgetItem(rx.medication));

        QString statusText = rx.taken ? "✔ Dispensed" : "⏳ Pending Pickup";
        QTableWidgetItem* statusItem = new QTableWidgetItem(statusText);
        statusItem->setForeground(rx.taken ? QColor("#27ae60") : QColor("#e67e22"));
        statusItem->setFont(QFont("", -1, QFont::Bold));
        rxTable->setItem(row, 2, statusItem);
    }

    if (rxList.isEmpty()) {
        rxTable->insertRow(0);
        QTableWidgetItem* noRx = new QTableWidgetItem("No prescriptions on record yet.");
        noRx->setForeground(QColor("#95a5a6"));
        rxTable->setItem(0, 0, noRx);
        rxTable->setSpan(0, 0, 1, 3);
    }
}