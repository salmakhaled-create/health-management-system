#include "addprescriptionpage.h"
#include "datastore.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QMessageBox>

AddPrescriptionPage::AddPrescriptionPage(QWidget* parent) : QWidget(parent) {

    patientNameEdit = new QLineEdit(this);
    patientIdEdit = new QLineEdit(this);
    pharmacistNameEdit= new QLineEdit(this);
    diagnosisEdit = new QLineEdit(this);
    medicationEdit = new QTextEdit(this);
    submitBtn = new QPushButton("Add Prescription", this);
    statusLabel = new QLabel(this);

    patientNameEdit->setPlaceholderText("e.g. Sara Ahmed");
    patientIdEdit->setPlaceholderText("e.g. 10234");
    pharmacistNameEdit->setPlaceholderText("e.g. Pharmacist Layla");
    diagnosisEdit->setPlaceholderText("e.g. Upper Respiratory Infection");
    medicationEdit->setPlaceholderText("e.g. Amoxicillin 500mg – twice daily for 7 days");
    medicationEdit->setFixedHeight(80);
    statusLabel->setStyleSheet("color: green; font-weight: bold;");

    QFormLayout* form = new QFormLayout;
    form->setSpacing(12);
    form->addRow("Patient Name:", patientNameEdit);
    form->addRow("Patient ID:", patientIdEdit);
    form->addRow("Pharmacist Name:", pharmacistNameEdit);
    form->addRow("Diagnosis:", diagnosisEdit);
    form->addRow("Medication:", medicationEdit);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(40, 30, 40, 30);
    layout->setSpacing(16);

    QLabel* title = new QLabel("Add Prescription", this);
    title->setStyleSheet("font-size: 20px; font-weight: bold; color: #2c3e50;");

    QLabel* note = new QLabel("Note: Prescriptions added here are marked as already dispensed.", this);
    note->setStyleSheet("color: #e67e22; font-size: 12px;");
    note->setWordWrap(true);

    layout->addWidget(title);
    layout->addWidget(note);
    layout->addSpacing(8);
    layout->addLayout(form);
    layout->addWidget(submitBtn);
    layout->addWidget(statusLabel);
    layout->addStretch();

    connect(submitBtn, &QPushButton::clicked, this, &AddPrescriptionPage::handleSubmit);
}

void AddPrescriptionPage::handleSubmit() {
    QString pName = patientNameEdit->text().trimmed();
    QString pId = patientIdEdit->text().trimmed();
    QString pharName = pharmacistNameEdit->text().trimmed();
    QString diagnosis = diagnosisEdit->text().trimmed();
    QString medication = medicationEdit->toPlainText().trimmed();

    if (pName.isEmpty() || pId.isEmpty() || pharName.isEmpty() ||
        diagnosis.isEmpty() || medication.isEmpty()) {
        QMessageBox::warning(this, "Incomplete Form", "Please fill in all fields.");
        return;
    }

    Prescription rx;
    rx.patientName = pName;
    rx.patientId = pId;
    rx.pharmacistName = pharName;
    rx.diagnosis = diagnosis;
    rx.medication = medication;
    rx.taken = true;

    DataStore::instance().addPrescription(rx);
    statusLabel->setText("✔ Prescription added for \"" + pName + "\".");

    patientNameEdit->clear();
    patientIdEdit->clear();
    pharmacistNameEdit->clear();
    diagnosisEdit->clear();
    medicationEdit->clear();

    emit prescriptionAdded();
}