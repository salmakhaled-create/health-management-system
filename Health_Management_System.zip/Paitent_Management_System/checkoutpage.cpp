#include "checkoutpage.h"
#include "datastore.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QMessageBox>

CheckOutPage::CheckOutPage(QWidget* parent) : QWidget(parent) {
    nameEdit       = new QLineEdit(this);
    idEdit         = new QLineEdit(this);
    diagnosisEdit  = new QLineEdit(this);
    medicationEdit = new QTextEdit(this);
    submitBtn      = new QPushButton("Check Out Patient", this);
    statusLabel    = new QLabel(this);

    nameEdit->setPlaceholderText("e.g. Sarah Ahmed");
    idEdit->setPlaceholderText("e.g. 10234");
    diagnosisEdit->setPlaceholderText("e.g. Acute Bronchitis");
    medicationEdit->setPlaceholderText("e.g. Amoxicillin 500mg – twice daily for 7 days\n(enter 'none' if no medication prescribed)");
    medicationEdit->setFixedHeight(90);
    statusLabel->setStyleSheet("color: green; font-weight: bold;");

    QFormLayout* form = new QFormLayout;
    form->setSpacing(12);
    form->addRow("Patient Name:",       nameEdit);
    form->addRow("Patient ID:",         idEdit);
    form->addRow("Diagnosis:",          diagnosisEdit);
    form->addRow("Medication / Notes:", medicationEdit);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(40, 30, 40, 30);
    layout->setSpacing(16);

    QLabel* title = new QLabel("Patient Check-Out", this);
    title->setStyleSheet("font-size: 20px; font-weight: bold; color: #2c3e50;");

    QLabel* note = new QLabel(
        "ℹ Medication will automatically be sent to the Pharmacy for pickup.", this);
    note->setStyleSheet("color: #2980b9; font-size: 12px;");
    note->setWordWrap(true);

    layout->addWidget(title);
    layout->addWidget(note);
    layout->addSpacing(8);
    layout->addLayout(form);
    layout->addWidget(submitBtn);
    layout->addWidget(statusLabel);
    layout->addStretch();

    connect(submitBtn, &QPushButton::clicked, this, &CheckOutPage::handleCheckOut);
}

void CheckOutPage::handleCheckOut() {
    QString name       = nameEdit->text().trimmed();
    QString id         = idEdit->text().trimmed();
    QString diagnosis  = diagnosisEdit->text().trimmed();
    QString medication = medicationEdit->toPlainText().trimmed();

    if (name.isEmpty() || id.isEmpty() || diagnosis.isEmpty() || medication.isEmpty()) {
        QMessageBox::warning(this, "Incomplete Form",
                             "Please fill in all fields before submitting.\n"
                             "Enter 'none' in Medication if nothing was prescribed.");
        return;
    }
    Patient* p = DataStore::instance().findById(id);
    if (!p) {
        QMessageBox::warning(this, "Patient Not Found","No patient found with ID: " + id + ".\nPlease check in the patient first.");
        return;
    }
    if (p->checkedOut) {
        QMessageBox::information(this, "Already Checked Out", "This patient has already been checked out.");
        return;
    }
    if (p->name.toLower() != name.toLower()) {
        QMessageBox::warning(this, "Name Mismatch", "The name entered does not match the record for ID: " + id);
        return;
    }
    DataStore::instance().checkOutPatient(id, diagnosis, medication);

    QString msg = "✔ Patient \"" + name + "\" checked out successfully.";
    if (medication.toLower() != "none")
        msg += "\n💊 Prescription sent to Pharmacy for pickup.";
    statusLabel->setText(msg);
    nameEdit->clear();
    idEdit->clear();
    diagnosisEdit->clear();
    medicationEdit->clear();
    emit patientCheckedOut();
}