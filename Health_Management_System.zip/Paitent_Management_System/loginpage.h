#ifndef LOGINPAGE_H
#define LOGINPAGE_H
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>

enum class LoginRole {
    Hospital,
    Pharmacy
};

class LoginPage : public QWidget {
    Q_OBJECT

public:
    explicit LoginPage(LoginRole role, QWidget* parent = nullptr);

signals:
    void loginSuccess();
    void backRequested();

private slots:
    void attemptLogin();

private:
    LoginRole role;
    QLineEdit* usernameEdit;
    QLineEdit* passwordEdit;
    QPushButton* loginBtn;
    QPushButton* backBtn;
    QLabel* errorLabel;
};

#endif
