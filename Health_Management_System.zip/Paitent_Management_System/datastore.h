#ifndef DATASTORE_H
#define DATASTORE_H
#include <QList>
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QStandardPaths>
#include <QDir>
#include <QDateTime>
#include "patient.h"
#include "prescription.h"
#include "visit.h"

class DataStore {
public:
    static DataStore& instance() {
        static DataStore store;
        return store;
    }
    // ─────────────── Patients ───────────────
    void addPatient(const Patient& p) {
        patients.append(p);
        save();
    }
    Patient* findById(const QString& id) {
        for (auto& p : patients)
            if (p.id == id) return &p;
        return nullptr;
    }
    const QList<Patient>& allPatients() const { return patients; }
    // Call this on checkout: updates patient, records a Visit, and queues a Prescription for pharmacy
    void checkOutPatient(const QString& id,
                         const QString& diagnosis,
                         const QString& medication) {
        Patient* p = findById(id);
        if (!p) return;
        p->diagnosis = diagnosis;
        p->medication = medication;
        p->checkedOut = true;
        // ── Record visit history ──
        Visit v;
        v.patientId = p->id;
        v.patientName = p->name;
        v.doctorName = p->doctorName;
        v.doctorSpecialization = p->doctorSpecialization;
        v.diagnosis = diagnosis;
        v.medication = medication;
        v.dateTime = QDateTime::currentDateTime().toString(Qt::ISODate);
        visits.append(v);
        // ── Auto-create prescription for pharmacy pickup ──
        // Only create if medication is not empty / "none"
        if (!medication.trimmed().isEmpty() &&
            medication.trimmed().toLower() != "none") {
            Prescription rx;
            rx.patientId = p->id;
            rx.patientName = p->name;
            rx.pharmacistName = "";
            rx.diagnosis = diagnosis;
            rx.medication = medication;
            rx.taken = false;
            prescriptions.append(rx);
        }
        save();
    }
    // ─────────────── Visits ───────────────
    QList<Visit> allVisitsFor(const QString& patientId) const {
        QList<Visit> result;
        for (const auto& v : visits)
            if (v.patientId == patientId)
                result.append(v);
        return result;
    }
    // ─────────────── Prescriptions ───────────────
    void addPrescription(const Prescription& rx) {
        prescriptions.append(rx);
        save();
    }
    // Pending = not yet picked up from pharmacy
    QList<Prescription*> pendingPrescriptionsFor(const QString& patientId) {
        QList<Prescription*> result;
        for (auto& rx : prescriptions)
            if (rx.patientId == patientId && !rx.taken)
                result.append(&rx);
        return result;
    }
    QList<Prescription> allPrescriptionsFor(const QString& patientId) const {
        QList<Prescription> result;
        for (const auto& rx : prescriptions)
            if (rx.patientId == patientId)
                result.append(rx);
        return result;
    }
    const QList<Prescription>& allPrescriptions() const { return prescriptions; }
    void markPrescriptionTaken(Prescription* rx) {
        if (rx) { rx->taken = true; save(); }
    }
    // ─────────────── Persistence ───────────────
    void save() const {
        // ── Patients ──
        QJsonArray patientArr;
        for (const auto& p : patients) {
            QJsonObject obj;
            obj["id"] = p.id;
            obj["name"] = p.name;
            obj["doctorName"] = p.doctorName;
            obj["doctorSpecialization"] = p.doctorSpecialization;
            obj["diagnosis"] = p.diagnosis;
            obj["medication"] = p.medication;
            obj["checkedOut"] = p.checkedOut;
            patientArr.append(obj);
        }

        // ── Visits ──
        QJsonArray visitArr;
        for (const auto& v : visits) {
            QJsonObject obj;
            obj["patientId"] = v.patientId;
            obj["patientName"] = v.patientName;
            obj["doctorName"] = v.doctorName;
            obj["doctorSpecialization"] = v.doctorSpecialization;
            obj["diagnosis"] = v.diagnosis;
            obj["medication"] = v.medication;
            obj["dateTime"] = v.dateTime;
            visitArr.append(obj);
        }

        // ── Prescriptions ──
        QJsonArray rxArr;
        for (const auto& rx : prescriptions) {
            QJsonObject obj;
            obj["patientId"] = rx.patientId;
            obj["patientName"] = rx.patientName;
            obj["pharmacistName"] = rx.pharmacistName;
            obj["diagnosis"] = rx.diagnosis;
            obj["medication"] = rx.medication;
            obj["taken"] = rx.taken;
            rxArr.append(obj);
        }

        QJsonObject root;
        root["patients"] = patientArr;
        root["visits"] = visitArr;
        root["prescriptions"] = rxArr;

        QDir().mkpath(QStandardPaths::writableLocation(
            QStandardPaths::AppDataLocation));

        QFile file(filePath());
        if (file.open(QIODevice::WriteOnly))
            file.write(QJsonDocument(root).toJson());
    }

    void load() {
        QFile file(filePath());
        if (!file.open(QIODevice::ReadOnly)) return;

        QJsonObject root = QJsonDocument::fromJson(file.readAll()).object();
        // ── Patients ──
        for (const auto& val : root["patients"].toArray()) {
            QJsonObject obj = val.toObject();
            Patient p;
            p.id = obj["id"].toString();
            p.name = obj["name"].toString();
            p.doctorName = obj["doctorName"].toString();
            p.doctorSpecialization = obj["doctorSpecialization"].toString();
            p.diagnosis = obj["diagnosis"].toString();
            p.medication = obj["medication"].toString();
            p.checkedOut = obj["checkedOut"].toBool();
            patients.append(p);
        }
        // ── Visits ──
        for (const auto& val : root["visits"].toArray()) {
            QJsonObject obj = val.toObject();
            Visit v;
            v.patientId = obj["patientId"].toString();
            v.patientName = obj["patientName"].toString();
            v.doctorName = obj["doctorName"].toString();
            v.doctorSpecialization = obj["doctorSpecialization"].toString();
            v.diagnosis = obj["diagnosis"].toString();
            v.medication = obj["medication"].toString();
            v.dateTime = obj["dateTime"].toString();
            visits.append(v);
        }
        // ── Prescriptions ──
        for (const auto& val : root["prescriptions"].toArray()) {
            QJsonObject obj = val.toObject();
            Prescription rx;
            rx.patientId = obj["patientId"].toString();
            rx.patientName = obj["patientName"].toString();
            rx.pharmacistName = obj["pharmacistName"].toString();
            rx.diagnosis = obj["diagnosis"].toString();
            rx.medication = obj["medication"].toString();
            rx.taken = obj["taken"].toBool();
            prescriptions.append(rx);
        }
    }

private:
    DataStore() = default;

    static QString filePath() {
        return QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/data.json";
    }

    QList<Patient> patients;
    QList<Visit> visits;
    QList<Prescription> prescriptions;
};

#endif