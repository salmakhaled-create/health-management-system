#ifndef CHECKOUTPAGE_H
#define CHECKOUTPAGE_H
#include <QWidget>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>

class CheckOutPage : public QWidget {
    Q_OBJECT
public:
    explicit CheckOutPage(QWidget* parent = nullptr);
signals:
    void patientCheckedOut();
private slots:
    void handleCheckOut();
private:
    QLineEdit* nameEdit;
    QLineEdit* idEdit;
    QLineEdit* diagnosisEdit;
    QTextEdit* medicationEdit;
    QPushButton* submitBtn;
    QLabel* statusLabel;
};

#endif
