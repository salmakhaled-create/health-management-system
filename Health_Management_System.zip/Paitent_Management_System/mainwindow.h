#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QTabWidget>
#include "hospitalpage.h"
#include "pharmacyPage.h"
#include "patientPortal.h"
#include "loginPage.h"

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() = default;
private slots:
    void showLanding();
    void showHospitalLogin();
    void showPharmacyLogin();
    void showHospitalModule();
    void showPharmacyModule();
    void showPatientPortal();
private:
    QStackedWidget* stack;
    QWidget* landingPage;
    LoginPage* hospitalLogin;
    LoginPage* pharmacyLogin;
    HospitalPage* hospitalPage;
    PharmacyPage* pharmacyPage;
    PatientPortal* patientPortal;

    void buildLandingPage();
};

#endif
