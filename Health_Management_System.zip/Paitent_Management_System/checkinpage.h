#ifndef CHECKINPAGE_H
#define CHECKINPAGE_H
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>

class CheckInPage : public QWidget {
    Q_OBJECT
public:
    explicit CheckInPage(QWidget* parent = nullptr);
signals:
    void patientCheckedIn();
private slots:
    void handleCheckIn();
private:
    QLineEdit* nameEdit;
    QLineEdit* idEdit;
    QLineEdit* doctorNameEdit;
    QLineEdit* doctorSpecEdit;
    QPushButton* submitBtn;
    QLabel* statusLabel;
};

#endif
