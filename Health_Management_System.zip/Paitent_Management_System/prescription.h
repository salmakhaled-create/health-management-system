#ifndef PRESCRIPTION_H
#define PRESCRIPTION_H

#include <QString>

struct Prescription {
    QString patientName;
    QString patientId;
    QString pharmacistName;
    QString diagnosis;
    QString medication;
    bool taken = false;
};

#endif