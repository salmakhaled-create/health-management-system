#include "pickupprescriptionpage.h"
#include "datastore.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QHeaderView>
#include <QMessageBox>

PickupPrescriptionPage::PickupPrescriptionPage(QWidget* parent) : QWidget(parent) {

    nameEdit  = new QLineEdit(this);
    idEdit    = new QLineEdit(this);
    searchBtn = new QPushButton("Search", this);
    nameEdit->setPlaceholderText("Patient name (optional)");
    idEdit->setPlaceholderText("Patient ID (required)");

    QFormLayout* form = new QFormLayout;
    form->setSpacing(10);
    form->addRow("Patient Name:", nameEdit);
    form->addRow("Patient ID:",   idEdit);

    resultsTable = new QTableWidget(this);
    resultsTable->setColumnCount(3);
    resultsTable->setHorizontalHeaderLabels({"Diagnosis", "Medication", "Source"});
    resultsTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    resultsTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    resultsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    resultsTable->verticalHeader()->setVisible(false);
    resultsTable->setAlternatingRowColors(true);

    markTakenBtn = new QPushButton("✔  Mark Selected as Picked Up", this);
    markTakenBtn->setStyleSheet("background: #27ae60;");

    statusLabel = new QLabel(this);
    statusLabel->setStyleSheet("color: green; font-weight: bold;");

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(40, 30, 40, 30);
    layout->setSpacing(14);

    QLabel* title = new QLabel("Pick Up Prescription", this);
    title->setStyleSheet("font-size: 20px; font-weight: bold; color: #2c3e50;");

    QLabel* hint = new QLabel(
        "Enter the patient ID to view their pending prescriptions from hospital checkout or manually added ones.", this);
    hint->setStyleSheet("color: #7f8c8d; font-size: 12px;");
    hint->setWordWrap(true);

    layout->addWidget(title);
    layout->addWidget(hint);
    layout->addSpacing(8);
    layout->addLayout(form);
    layout->addWidget(searchBtn);
    layout->addWidget(resultsTable);
    layout->addWidget(markTakenBtn);
    layout->addWidget(statusLabel);
    layout->addStretch();

    connect(searchBtn,    &QPushButton::clicked, this, &PickupPrescriptionPage::handleSearch);
    connect(markTakenBtn, &QPushButton::clicked, this, &PickupPrescriptionPage::handleMarkTaken);
    connect(idEdit, &QLineEdit::returnPressed,   this, &PickupPrescriptionPage::handleSearch);
}

void PickupPrescriptionPage::handleSearch() {
    QString name = nameEdit->text().trimmed();
    QString id   = idEdit->text().trimmed();

    if (id.isEmpty()) {
        QMessageBox::warning(this, "Missing ID", "Please enter the patient ID.");
        return;
    }

    resultsTable->setRowCount(0);
    statusLabel->clear();

    QList<Prescription*> pending = DataStore::instance().pendingPrescriptionsFor(id);

    if (!name.isEmpty() && !pending.isEmpty()) {
        if (pending.first()->patientName.toLower() != name.toLower()) {
            statusLabel->setStyleSheet("color: #e74c3c; font-weight: bold;");
            statusLabel->setText("⚠ Name does not match our records for this ID.");
            return;
        }
    }

    if (pending.isEmpty()) {
        statusLabel->setStyleSheet("color: #e67e22; font-weight: bold;");
        statusLabel->setText("No pending prescriptions found for ID: " + id);
        return;
    }

    statusLabel->setStyleSheet("color: #2c3e50;");
    statusLabel->setText(QString::number(pending.size()) + " pending prescription(s) found.");

    for (Prescription* rx : pending) {
        int row = resultsTable->rowCount();
        resultsTable->insertRow(row);
        resultsTable->setItem(row, 0, new QTableWidgetItem(rx->diagnosis));
        resultsTable->setItem(row, 1, new QTableWidgetItem(rx->medication));

        QString source = rx->pharmacistName.isEmpty() ? "Hospital Checkout" : "Pharmacy: " + rx->pharmacistName;
        resultsTable->setItem(row, 2, new QTableWidgetItem(source));

        resultsTable->item(row, 0)->setData(Qt::UserRole,
                                            QVariant::fromValue(static_cast<void*>(rx)));
    }
}

void PickupPrescriptionPage::handleMarkTaken() {
    int row = resultsTable->currentRow();
    if (row < 0) {
        QMessageBox::information(this, "No Selection",
                                 "Please select a prescription row first.");
        return;
    }

    QTableWidgetItem* item = resultsTable->item(row, 0);
    Prescription* rx = static_cast<Prescription*>(
        item->data(Qt::UserRole).value<void*>());

    if (!rx) return;

    DataStore::instance().markPrescriptionTaken(rx);

    statusLabel->setStyleSheet("color: green; font-weight: bold;");
    statusLabel->setText("✔ Prescription marked as picked up and saved.");
    resultsTable->removeRow(row);
}
