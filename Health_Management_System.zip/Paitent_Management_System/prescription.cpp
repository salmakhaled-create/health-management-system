#include "prescription.h"

prescription::prescription() {}
