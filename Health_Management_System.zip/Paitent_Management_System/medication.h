#ifndef MEDICATION_H
#define MEDICATION_H

class medication
{
public:
    medication();
};

#endif // MEDICATION_H
