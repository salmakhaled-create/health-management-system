#include "addpage.h"

addpage::addpage() {}
