#include "hospitalpage.h"
#include <QVBoxLayout>

HospitalPage::HospitalPage(QWidget* parent) : QWidget(parent) {

    checkInPage = new CheckInPage(this);
    checkOutPage = new CheckOutPage(this);
    dataPage = new DataPage(this);
    tabs = new QTabWidget(this);

    tabs->addTab(checkInPage, "Check In");
    tabs->addTab(checkOutPage, "Check Out");
    tabs->addTab(dataPage, "Patient Data");

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->addWidget(tabs);

    connect(checkInPage, &CheckInPage::patientCheckedIn, dataPage, &DataPage::refreshTable);
    connect(checkOutPage, &CheckOutPage::patientCheckedOut, dataPage, &DataPage::refreshTable);
}