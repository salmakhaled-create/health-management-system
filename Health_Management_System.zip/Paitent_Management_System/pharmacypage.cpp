#include "pharmacypage.h"
#include <QVBoxLayout>

PharmacyPage::PharmacyPage(QWidget* parent) : QWidget(parent) {

    addPage    = new AddPrescriptionPage(this);
    pickupPage = new PickupPrescriptionPage(this);

    tabs = new QTabWidget(this);
    tabs->addTab(pickupPage, "Pick Up Prescription");
    tabs->addTab(addPage,    "Add Prescription");

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->addWidget(tabs);
}
