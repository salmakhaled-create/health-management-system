#include "medication.h"

medication::medication() {}
