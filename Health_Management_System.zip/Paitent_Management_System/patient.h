#ifndef PATIENT_H
#define PATIENT_H


#include <QString>
struct Patient {
    QString name;
    QString id;
    QString doctorName;
    QString doctorSpecialization;

    QString diagnosis;
    QString medication;
    bool checkedOut = false;
};

#endif
